import { SignUp } from "@clerk/nextjs";

const SignUpPage = () => {
  return <SignUp />;
};

export default SignUpPage;
